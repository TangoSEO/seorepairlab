---
description: Learn about image handling in Astro Cactus
---

This is an example of a custom intro on a tag page. Its markdown can be found in `src/content/tag/image.md`.

Posts tagged with "image" demonstrate various image-related features including cover images, social media cards, and image optimization.
