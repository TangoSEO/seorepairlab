
import __ASTRO_IMAGE_IMPORT_Z38Rwq from "./logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fpost%2Fmarkdown-elements%2Findex.md";
import __ASTRO_IMAGE_IMPORT_ZCroyp from "./cover.png?astroContentImageFlag=&importer=src%2Fcontent%2Fpost%2Fcover-image%2Findex.md";
export default new Map([["./logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fpost%2Fmarkdown-elements%2Findex.md", __ASTRO_IMAGE_IMPORT_Z38Rwq], ["./cover.png?astroContentImageFlag=&importer=src%2Fcontent%2Fpost%2Fcover-image%2Findex.md", __ASTRO_IMAGE_IMPORT_ZCroyp]]);
		